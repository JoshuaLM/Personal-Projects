package pasur;

import ch.aplu.jcardgame.Card;

import java.util.ArrayList;

public class SurRule extends Rule{
    private int points;
    public SurRule(int points){
        this.points = points;
    }
    public int getValue(ArrayList<Card> sur){
        return sur.size()*points;
    }
}
