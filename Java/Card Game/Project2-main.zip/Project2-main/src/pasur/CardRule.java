package pasur;

import ch.aplu.jcardgame.Card;

import java.util.ArrayList;

public class CardRule extends Rule{
    private Suit suit;
    private Rank rank;
    private int points;

    public CardRule(Suit suit,Rank rank, int points) {
        this.suit = suit;
        this.rank = rank;
        this.points = points;
    }
    @Override
    public int getValue(ArrayList<Card> picked) {
        for (int i = 0;i<picked.size();i++){
            if (picked.get(i).getRank() == rank && picked.get(i).getSuit() == suit){
                return points;
            }
        }
        return 0;
    }

}
