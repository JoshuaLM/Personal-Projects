package pasur;

public class RuleFactory {
    private static RuleFactory instance;

    /*
    The below properties can be configurable in the future
    */
    private int MOST_CLUBS_POINTS = 7;
    private int NUM_OF_CLUBS = 7;
    private int TEN_OF_DIAMONDS = 3;
    private int TWO_OF_CLUBS = 2;
    private int EACH_ACE =1;
    private int EACH_JACK =1;
    private int EACH_SUR = 5;

    private RuleFactory(){}
    public static RuleFactory getInstance(){
        if (instance==null) instance = new RuleFactory();
        return instance;
    }
    public Rule createRule(String ruleName){
        switch(ruleName) {
            case "surRule":
                return createSurRule();
            default:
                return createCompositeRule();
        }

    }

    private Rule createCompositeRule(){
        RuleComposite newRule = new RuleComposite();
        /*reward for having more than a certain number of cards of a certain suit*/
        newRule.addRule(new SuitRule(Suit.CLUBS,NUM_OF_CLUBS,MOST_CLUBS_POINTS));
        /*reward for having certain cards*/
        newRule.addRule(new CardRule(Suit.DIAMONDS,Rank.TEN,TEN_OF_DIAMONDS));
        newRule.addRule(new CardRule(Suit.CLUBS,Rank.TWO,TWO_OF_CLUBS));

        /*reward for having certain ranks*/
        newRule.addRule(new RankRule(Rank.ACE,EACH_ACE));
        newRule.addRule(new RankRule(Rank.JACK, EACH_JACK));

        return newRule;
    }

    private Rule createSurRule(){
        return new SurRule(EACH_SUR);
    }


}
