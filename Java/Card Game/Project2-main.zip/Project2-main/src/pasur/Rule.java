package pasur;

import ch.aplu.jcardgame.Card;

import java.util.ArrayList;

public abstract class Rule {
    public abstract int getValue(ArrayList<Card> cards);
}
