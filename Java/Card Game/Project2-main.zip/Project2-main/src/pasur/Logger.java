package pasur;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Logger {

	private static final String FILE_NAME = "pasur.log";
	private static Logger instance = null;
	private File file;
	private FileWriter fw;
	
	public Logger() throws IOException {
		file = new File(FILE_NAME);
		fw = new FileWriter(FILE_NAME);
	}

	public static Logger getInstance() throws IOException {
		if (instance == null)
			instance = new Logger();
		return instance;
	}
	
    public void log(String output) throws IOException {
    	fw.write(output+"\r\n");
    }
    
    public void close() throws IOException {
    	fw.close();
    }
}
