package pasur;

import ch.aplu.jcardgame.Card;
import java.util.ArrayList;

public class CardFacade {
    private RuleFactory ruleFactory;

    public CardFacade(){
        this.ruleFactory = RuleFactory.getInstance();
    }
    public int getValue(Player player){
        int totalPoints = 0;
        /*able to dynamically update rules during game*/
        Rule pickedRule = this.ruleFactory.createRule("composite");
        Rule surRule = this.ruleFactory.createRule("surRule");

        ArrayList<Card> pickedCards =player.getPickedCards().getCardList();
        ArrayList<Card> sursList = player.getSurs().getCardList();
        pickedCards.addAll(sursList);

        totalPoints += pickedRule.getValue(pickedCards);
        totalPoints += surRule.getValue(sursList);

        return totalPoints;

    }


}
