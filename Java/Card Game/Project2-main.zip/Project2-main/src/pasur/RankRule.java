package pasur;

import ch.aplu.jcardgame.Card;

import java.util.ArrayList;

public class RankRule extends Rule{
    private int points;
    private Rank rank;
    public RankRule(Rank rank, int points){
        this.rank = rank;
        this.points = points;
    }
    @Override
    public int getValue(ArrayList<Card> picked) {
        int counts = 0;
        for (Card card : picked) {
            if (card.getRank() == rank) {
                counts++;
            }
        }
        return counts * points;
    }
}
