package pasur;

import ch.aplu.jcardgame.Card;

import java.util.ArrayList;

public class SuitRule extends Rule{
    private int points;
    private int frequency;
    private Suit suit;

    public SuitRule(Suit suit,int frequency,int points){
        this.suit = suit;
        this.frequency=frequency;
        this.points = points;
    }
    public  int getValue(ArrayList<Card> picked){
        int counts = 0;
        for (Card card : picked) {
            if (card.getSuit() == this.suit) {
                counts++;
            }
        }
        return counts >= frequency ? points:0;
    }
}
