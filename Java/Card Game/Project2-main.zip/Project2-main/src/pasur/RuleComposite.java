package pasur;

import ch.aplu.jcardgame.Card;

import java.util.ArrayList;

public class RuleComposite extends Rule{

    private ArrayList<Rule> ruleList;
    @Override
    public int getValue(ArrayList<Card> picked) {
        int totalPoints = 0;
        for (Rule rule : ruleList) {
            totalPoints += rule.getValue(picked);
        }
        return totalPoints;
    }
    public void addRule(Rule rule){
        if (ruleList == null) {
            ruleList = new ArrayList<>();
        }
        ruleList.add(rule);
    }
}
